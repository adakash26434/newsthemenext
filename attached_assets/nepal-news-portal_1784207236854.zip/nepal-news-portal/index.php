<?php
/**
 * Nepal News Portal — Front Controller
 * Place everything in the document root (public_html/).
 * Requires: PHP 8.0+, SQLite3, mod_rewrite (Apache)
 */

define('APP_START', true);

require_once __DIR__ . '/src/config.php';
require_once __DIR__ . '/src/database.php';
require_once __DIR__ . '/src/helpers.php';
require_once __DIR__ . '/src/layout/admin_layout.php';

// Start session
session_name(SESSION_NAME);
if (session_status() === PHP_SESSION_NONE) session_start();

// Auto-initialize DB if needed
try {
    get_db()->query("SELECT 1 FROM settings LIMIT 1");
} catch (Exception $e) {
    require __DIR__ . '/src/init.php';
}

// ── Router ─────────────────────────────────────────────────
$uri  = strtok($_SERVER['REQUEST_URI'], '?');
$uri  = rtrim($uri, '/') ?: '/';
$meth = $_SERVER['REQUEST_METHOD'];

// Helper: match simple patterns
function route_match(string $pattern, string $uri): array|false {
    $regex = preg_replace('#\{[^}]+\}#', '([^/]+)', $pattern);
    $regex = '#^' . $regex . '$#';
    if (preg_match($regex, $uri, $m)) {
        array_shift($m);
        return $m;
    }
    return false;
}

// ── Admin POST routes ──────────────────────────────────────
if ($meth === 'POST') {

    // Admin login
    if ($uri === '/admin/login') {
        csrf_check();
        $u = trim($_POST['username'] ?? '');
        $p = $_POST['password'] ?? '';
        if (admin_login($u, $p)) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_user']      = $u;
            redirect('admin');
        } else {
            flash_set('error', 'गलत प्रयोगकर्ता नाम वा पासवर्ड।');
            redirect('admin/login');
        }
    }

    // Admin logout
    if ($uri === '/admin/logout') {
        csrf_check();
        session_destroy();
        redirect('admin/login');
    }

    // Save article
    if ($uri === '/admin/articles/save') {
        admin_check();
        csrf_check();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $pub = $_POST['published_at'] ?? null;
        if ($pub) $pub = date('Y-m-d H:i:s', strtotime($pub));
        $data = [
            'title'       => trim($_POST['title'] ?? ''),
            'title_np'    => trim($_POST['title_np'] ?? ''),
            'slug'        => slug_from_title(trim($_POST['slug'] ?? $_POST['title'] ?? '')),
            'content'     => $_POST['content'] ?? '',
            'content_np'  => $_POST['content_np'] ?? '',
            'summary'     => trim($_POST['summary'] ?? ''),
            'summary_np'  => trim($_POST['summary_np'] ?? ''),
            'language'    => in_array($_POST['language']??'',['np','en']) ? $_POST['language'] : 'np',
            'status'      => in_array($_POST['status']??'',['draft','published']) ? $_POST['status'] : 'draft',
            'featured'    => isset($_POST['featured']) ? 1 : 0,
            'image_url'   => trim($_POST['image_url'] ?? ''),
            'category_id' => (int)($_POST['category_id'] ?? 0),
            'author_id'   => (int)($_POST['author_id'] ?? 0),
            'published_at'=> $pub ?: date('Y-m-d H:i:s'),
            'tag_ids'     => array_map('intval', $_POST['tag_ids'] ?? []),
        ];
        if (!$data['title'] || !$data['category_id'] || !$data['author_id']) {
            flash_set('error', 'शीर्षक, श्रेणी र लेखक अनिवार्य छ।');
            redirect($id ? "admin/articles?action=edit&id=$id" : 'admin/articles?action=new');
        }
        // Ensure slug uniqueness
        $base_slug = $data['slug'];
        $i = 1;
        while (true) {
            $conflict = db_fetch("SELECT id FROM articles WHERE slug=?",[$data['slug']]);
            if (!$conflict || ($id && $conflict['id'] == $id)) break;
            $data['slug'] = $base_slug . '-' . $i++;
        }
        $new_id = save_article($data, $id);
        flash_set('success', $id ? 'लेख सफलतापूर्वक अपडेट भयो।' : 'नयाँ लेख प्रकाशित भयो।');
        redirect("admin/articles?action=edit&id=$new_id");
    }

    // Delete article
    if ($uri === '/admin/articles/delete') {
        admin_check(); csrf_check();
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            db_query("DELETE FROM article_tags WHERE article_id=?", [$id]);
            db_query("DELETE FROM articles WHERE id=?", [$id]);
            flash_set('success', 'लेख मेटाइयो।');
        }
        redirect('admin/articles');
    }

    // Save category
    if ($uri === '/admin/categories/save') {
        admin_check(); csrf_check();
        $id = (int)($_POST['id'] ?? 0) ?: null;
        $name    = trim($_POST['name'] ?? '');
        $name_np = trim($_POST['name_np'] ?? '');
        $slug    = trim($_POST['slug'] ?? '');
        $color   = trim($_POST['color'] ?? '#991B1B');
        $sort    = (int)($_POST['sort_order'] ?? 0);
        if (!$name || !$slug) { flash_set('error', 'नाम र slug अनिवार्य।'); redirect('admin/categories'); }
        if ($id) {
            db_query("UPDATE categories SET name=?,name_np=?,slug=?,color=?,sort_order=? WHERE id=?",
                [$name,$name_np,$slug,$color,$sort,$id]);
            flash_set('success','श्रेणी अपडेट भयो।');
        } else {
            db_query("INSERT INTO categories (name,name_np,slug,color,sort_order) VALUES (?,?,?,?,?)",
                [$name,$name_np,$slug,$color,$sort]);
            flash_set('success','नयाँ श्रेणी थपियो।');
        }
        redirect('admin/categories');
    }

    // Delete category
    if ($uri === '/admin/categories/delete') {
        admin_check(); csrf_check();
        $id = (int)($_POST['id'] ?? 0);
        if ($id) { db_query("DELETE FROM categories WHERE id=?",[$id]); flash_set('success','श्रेणी मेटाइयो।'); }
        redirect('admin/categories');
    }

    // Save author
    if ($uri === '/admin/authors/save') {
        admin_check(); csrf_check();
        $id  = (int)($_POST['id'] ?? 0) ?: null;
        $name= trim($_POST['name'] ?? '');
        $np  = trim($_POST['name_np'] ?? '');
        $slug= trim($_POST['slug'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $av  = trim($_POST['avatar_url'] ?? '');
        if (!$name||!$slug){flash_set('error','नाम र slug अनिवार्य।');redirect('admin/authors');}
        if ($id) {
            db_query("UPDATE authors SET name=?,name_np=?,slug=?,bio=?,avatar_url=? WHERE id=?",[$name,$np,$slug,$bio,$av,$id]);
            flash_set('success','लेखक अपडेट भयो।');
        } else {
            db_query("INSERT INTO authors (name,name_np,slug,bio,avatar_url) VALUES (?,?,?,?,?)",[$name,$np,$slug,$bio,$av]);
            flash_set('success','नयाँ लेखक थपियो।');
        }
        redirect('admin/authors');
    }

    // Delete author
    if ($uri === '/admin/authors/delete') {
        admin_check(); csrf_check();
        $id=(int)($_POST['id']??0);
        if($id){db_query("DELETE FROM authors WHERE id=?",[$id]);flash_set('success','लेखक मेटाइयो.');}
        redirect('admin/authors');
    }

    // Save tag
    if ($uri === '/admin/tags/save') {
        admin_check(); csrf_check();
        $name = trim($_POST['name']??'');
        $slug = trim($_POST['slug']??'');
        if (!$name||!$slug){flash_set('error','नाम र slug अनिवार्य।');redirect('admin/tags');}
        try {
            db_query("INSERT INTO tags (name,slug) VALUES (?,?)",[$name,$slug]);
            flash_set('success','नयाँ ट्याग थपियो।');
        } catch(Exception $e){ flash_set('error','यो slug पहिले नै छ।'); }
        redirect('admin/tags');
    }

    // Delete tag
    if ($uri === '/admin/tags/delete') {
        admin_check(); csrf_check();
        $id=(int)($_POST['id']??0);
        if($id){db_query("DELETE FROM tags WHERE id=?",[$id]);flash_set('success','ट्याग मेटाइयो.');}
        redirect('admin/tags');
    }

    // Save advertisement
    if ($uri === '/admin/advertisements/save') {
        admin_check(); csrf_check();
        $id      = (int)($_POST['id']??0) ?: null;
        $title   = trim($_POST['title']??'');
        $type    = in_array($_POST['type']??'',['image','code','text'])?$_POST['type']:'image';
        $pos     = trim($_POST['position']??'sidebar-top');
        $img     = trim($_POST['image_url']??'');
        $code    = $_POST['code']??'';
        $link    = trim($_POST['link_url']??'');
        $sort    = (int)($_POST['sort_order']??0);
        $active  = isset($_POST['active']) ? 1 : 0;
        if (!$title){flash_set('error','शीर्षक अनिवार्य।');redirect('admin/advertisements');}
        if ($id) {
            db_query("UPDATE advertisements SET title=?,type=?,image_url=?,code=?,link_url=?,position=?,sort_order=?,active=?,updated_at=datetime('now') WHERE id=?",
                [$title,$type,$img,$code,$link,$pos,$sort,$active,$id]);
            flash_set('success','विज्ञापन अपडेट भयो।');
        } else {
            db_query("INSERT INTO advertisements (title,type,image_url,code,link_url,position,sort_order,active) VALUES (?,?,?,?,?,?,?,?)",
                [$title,$type,$img,$code,$link,$pos,$sort,$active]);
            flash_set('success','नयाँ विज्ञापन थपियो।');
        }
        redirect('admin/advertisements');
    }

    // Toggle ad active
    if ($uri === '/admin/advertisements/toggle') {
        admin_check(); csrf_check();
        $id=(int)($_POST['id']??0);
        if($id){db_query("UPDATE advertisements SET active=1-active WHERE id=?",[$id]);}
        redirect('admin/advertisements');
    }

    // Delete advertisement
    if ($uri === '/admin/advertisements/delete') {
        admin_check(); csrf_check();
        $id=(int)($_POST['id']??0);
        if($id){db_query("DELETE FROM advertisements WHERE id=?",[$id]);flash_set('success','विज्ञापन मेटाइयो.');}
        redirect('admin/advertisements');
    }

    // Newsletter subscribe (public)
    if ($uri === '/newsletter/subscribe') {
        csrf_check();
        $email = trim($_POST['email'] ?? '');
        if (save_newsletter_email($email)) {
            flash_set('success', '✅ न्यूजलेटरमा सफलतापूर्वक सदस्य बन्नुभयो!');
        } else {
            flash_set('error', '❌ इमेल अमान्य वा पहिले नै दर्ता भएको छ।');
        }
        // Redirect back to referring page or home
        $ref = $_SERVER['HTTP_REFERER'] ?? '/';
        header('Location: ' . $ref);
        exit;
    }

    // Save settings
    if ($uri === '/admin/settings/save') {
        admin_check(); csrf_check();
        $text_keys = ['site_name','site_name_en','site_tagline','site_logo_text','site_logo_url',
                      'primary_color','nav_color','accent_color','contact_email','contact_phone',
                      'contact_address','footer_about','social_facebook','social_twitter',
                      'social_youtube','social_instagram','meta_keywords','google_analytics',
                      'ticker_label','epaper_url','admin_username'];
        foreach ($text_keys as $k) {
            if (isset($_POST[$k])) save_setting($k, trim($_POST[$k]));
        }
        // Password update
        $new_pass  = $_POST['admin_password_new'] ?? '';
        $conf_pass = $_POST['admin_password_confirm'] ?? '';
        if ($new_pass !== '') {
            if ($new_pass !== $conf_pass) {
                flash_set('error','Password confirm मिलेन। अन्य सेटिङ्स सेभ भए।');
                redirect('admin/settings');
            }
            save_setting('admin_password', $new_pass);
        }
        flash_set('success','सेटिङ्स सफलतापूर्वक सेभ भयो।');
        redirect('admin/settings');
    }
}

// ── GET routes ─────────────────────────────────────────────

// Home
if ($uri === '/') {
    require SRC_DIR . '/pages/home.php'; exit;
}

// Search
if ($uri === '/search') {
    require SRC_DIR . '/pages/search.php'; exit;
}

// Article: /article/{slug}
if ($m = route_match('/article/{slug}', $uri)) {
    $_slug = $m[0];
    require SRC_DIR . '/pages/article.php'; exit;
}

// Category: /category/{slug}
if ($m = route_match('/category/{slug}', $uri)) {
    $_cat_slug = $m[0];
    require SRC_DIR . '/pages/category.php'; exit;
}

// Author: /author/{slug}
if ($m = route_match('/author/{slug}', $uri)) {
    $_author_slug = $m[0];
    require SRC_DIR . '/pages/author.php'; exit;
}

// Admin: /admin or /admin/
if ($uri === '/admin') {
    admin_check();
    require SRC_DIR . '/admin/dashboard.php'; exit;
}

// Admin login
if ($uri === '/admin/login') {
    if (is_admin()) redirect('admin');
    require SRC_DIR . '/admin/login.php'; exit;
}

// Admin articles list
if ($uri === '/admin/articles') {
    admin_check();
    if (isset($_GET['action']) && in_array($_GET['action'],['new','edit'])) {
        require SRC_DIR . '/admin/article_form.php';
    } else {
        require SRC_DIR . '/admin/articles.php';
    }
    exit;
}

// Admin categories
if ($uri === '/admin/categories') {
    admin_check();
    require SRC_DIR . '/admin/categories.php'; exit;
}

// Admin authors
if ($uri === '/admin/authors') {
    admin_check();
    require SRC_DIR . '/admin/authors.php'; exit;
}

// Admin tags
if ($uri === '/admin/tags') {
    admin_check();
    require SRC_DIR . '/admin/tags.php'; exit;
}

// Admin advertisements
if ($uri === '/admin/advertisements') {
    admin_check();
    require SRC_DIR . '/admin/advertisements.php'; exit;
}

// Admin settings
if ($uri === '/admin/settings') {
    admin_check();
    require SRC_DIR . '/admin/settings.php'; exit;
}

// 404
http_response_code(404);
require SRC_DIR . '/pages/404.php';
