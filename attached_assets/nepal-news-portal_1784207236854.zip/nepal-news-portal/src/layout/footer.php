<?php
$_f_cats   = get_categories();
$_f_fb     = setting('social_facebook','');
$_f_tw     = setting('social_twitter','');
$_f_yt     = setting('social_youtube','');
$_f_ig     = setting('social_instagram','');
$_f_about  = setting('footer_about', site_name() . ' — नेपालको विश्वसनीय समाचार पोर्टल।');
$_f_email  = setting('contact_email','');
$_f_phone  = setting('contact_phone','');
$_f_addr   = setting('contact_address','काठमाडौं, नेपाल');
$_f_recent = get_articles(['status'=>'published','limit'=>4,'order'=>'a.published_at DESC']);
?>
</main>

<!-- ── Footer ── -->
<footer class="site-footer">
  <div class="max-w-7xl mx-auto px-4">

    <!-- Top footer grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 pb-8">

      <!-- Brand + Social -->
      <div>
        <?php if (site_logo_url()): ?>
          <img src="<?= h(site_logo_url()) ?>" alt="<?= h(site_name()) ?>" class="h-10 mb-3" style="filter:brightness(0) invert(1)">
        <?php else: ?>
          <div class="text-2xl font-extrabold text-white mb-1"><?= h(site_logo_text()) ?></div>
        <?php endif; ?>
        <p class="text-sm leading-relaxed mb-4" style="color:rgba(255,255,255,0.65)"><?= h($_f_about) ?></p>
        <?php if ($_f_email || $_f_phone || $_f_addr): ?>
        <div class="space-y-1 text-xs" style="color:rgba(255,255,255,0.65)">
          <?php if ($_f_addr):  ?><p>📍 <?= h($_f_addr) ?></p><?php endif; ?>
          <?php if ($_f_phone): ?><p>📞 <?= h($_f_phone) ?></p><?php endif; ?>
          <?php if ($_f_email): ?>
            <p>✉️ <a href="mailto:<?= h($_f_email) ?>" class="hover:text-white"><?= h($_f_email) ?></a></p>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <!-- Social icons -->
        <div class="flex gap-2 mt-4">
          <?php if ($_f_fb): ?>
          <a href="<?= h($_f_fb) ?>" class="social-link" target="_blank" rel="noopener" title="Facebook">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
          </a>
          <?php endif; ?>
          <?php if ($_f_tw): ?>
          <a href="<?= h($_f_tw) ?>" class="social-link" target="_blank" rel="noopener" title="Twitter/X">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
          </a>
          <?php endif; ?>
          <?php if ($_f_yt): ?>
          <a href="<?= h($_f_yt) ?>" class="social-link" target="_blank" rel="noopener" title="YouTube">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 001.95-1.96A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon fill="rgba(127,29,29,1)" points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
          </a>
          <?php endif; ?>
          <?php if ($_f_ig): ?>
          <a href="<?= h($_f_ig) ?>" class="social-link" target="_blank" rel="noopener" title="Instagram">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5"/><path fill="rgba(127,29,29,0.9)" d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><circle cx="17.5" cy="6.5" r="1" fill="rgba(127,29,29,0.9)"/></svg>
          </a>
          <?php endif; ?>
        </div>
      </div>

      <!-- Categories -->
      <div>
        <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider border-b border-white border-opacity-20 pb-2">श्रेणीहरू</h4>
        <ul class="space-y-1.5">
          <?php foreach (array_slice($_f_cats, 0, 8) as $_fc): ?>
            <li>
              <a href="/category/<?= h($_fc['slug']) ?>"
                 class="text-sm flex items-center gap-2 transition-colors hover:text-white"
                 style="color:rgba(255,255,255,0.65)">
                <span style="width:6px;height:6px;border-radius:50%;background:<?= h($_fc['color']?:'#FCA5A5') ?>;display:inline-block;flex-shrink:0"></span>
                <?= h($_fc['name_np'] ?: $_fc['name']) ?>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- Recent articles -->
      <div>
        <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider border-b border-white border-opacity-20 pb-2">ताजा समाचार</h4>
        <ul class="space-y-3">
          <?php foreach ($_f_recent as $_fr): ?>
          <li>
            <a href="/article/<?= h($_fr['slug']) ?>"
               class="text-sm leading-snug transition-colors hover:text-white"
               style="color:rgba(255,255,255,0.7);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">
              <?= h($_fr['title']) ?>
            </a>
            <span style="font-size:0.68rem;color:rgba(255,255,255,0.4)"><?= time_ago($_fr['published_at']??$_fr['created_at']) ?></span>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- Newsletter + quick links -->
      <div>
        <h4 class="text-white font-bold mb-4 text-sm uppercase tracking-wider border-b border-white border-opacity-20 pb-2">न्यूजलेटर</h4>
        <p class="text-xs mb-3" style="color:rgba(255,255,255,0.65)">ताजा समाचार सिधै इमेलमा पाउनुस्।</p>
        <form method="POST" action="/newsletter/subscribe" class="mb-4">
          <?= csrf_field() ?>
          <div class="flex">
            <input type="email" name="email" class="footer-newsletter-input" placeholder="तपाईंको इमेल..." required>
            <button type="submit" class="footer-newsletter-btn">सदस्य</button>
          </div>
        </form>
        <h4 class="text-white font-bold mb-2 text-xs uppercase tracking-wider">द्रुत लिंक</h4>
        <ul class="space-y-1 text-sm" style="color:rgba(255,255,255,0.65)">
          <li><a href="/" class="hover:text-white transition-colors">🏠 गृहपृष्ठ</a></li>
          <li><a href="/search" class="hover:text-white transition-colors">🔍 समाचार खोज्नुस्</a></li>
          <li><a href="/admin" class="hover:text-white transition-colors">⚙️ Admin Panel</a></li>
        </ul>
      </div>

    </div>

    <!-- Footer bottom bar -->
    <div class="footer-bottom">
      <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>&copy; <?= date('Y') ?> <?= h(site_name_en()) ?>. सर्वाधिकार सुरक्षित।</span>
        <span>Powered by PHP &amp; SQLite &nbsp;|&nbsp; <?= bs_date_today() ?></span>
      </div>
    </div>

  </div>
</footer>

</body>
</html>
