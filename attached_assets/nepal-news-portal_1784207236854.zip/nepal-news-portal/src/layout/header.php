<?php
$_categories   = get_categories();
$_current_path = current_url();
$_site_name    = site_name();
$_site_tagline = site_tagline();
$_logo_url     = site_logo_url();
$_logo_text    = site_logo_text();
$_primary      = primary_color();
$_nav_color    = nav_color();
$_ticker_label = setting('ticker_label', 'ताजा खबर');

// BS date helper — approximate conversion (offset +56/57 years)
function bs_date_today(): string {
    $y = (int)date('Y') + 57;
    $m = (int)date('n');
    $d = (int)date('j');
    $days_np = ['आइतबार','सोमबार','मंगलबार','बुधबार','बिहीबार','शुक्रबार','शनिबार'];
    $dow = $days_np[(int)date('w')];
    $months = NP_MONTHS;
    return "{$y} {$months[$m]} {$d} गते {$dow}";
}

// Category emoji icons
$cat_icons = [
    'arthatantra'  => '💰','banking'   => '🏦','bima'      => '🛡️',
    'share-bazar'  => '📈','corporate' => '🏢','paryatan'  => '✈️',
    'rajniti'      => '🏛️','samaj'     => '👥','bikas'     => '🔨',
    'bichar'       => '💭','antarwarta'=> '🎤','sampadakiya'=> '📝',
    'sports'       => '⚽','technology'=> '💻','world'      => '🌍',
];
?>
<!DOCTYPE html>
<html lang="ne" data-theme="light"
  x-data="{
    darkMode: (localStorage.getItem('theme')==='dark'),
    searchOpen: false,
    scrolled: false,
    backTop: false,
    init() {
      if (this.darkMode) document.documentElement.setAttribute('data-theme','dark');
      this.$watch('darkMode', v => {
        document.documentElement.setAttribute('data-theme', v?'dark':'light');
        localStorage.setItem('theme', v?'dark':'light');
      });
      window.addEventListener('scroll', () => {
        this.scrolled = window.scrollY > 60;
        this.backTop  = window.scrollY > 400;
        const el = document.getElementById('read-prog');
        if (el) {
          const d = document.documentElement;
          const pct = (d.scrollTop/(d.scrollHeight - d.clientHeight))*100;
          el.style.width = Math.min(pct,100) + '%';
        }
      });
    }
  }"
  x-init="init()">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($page_title ?? $_site_name) ?></title>
<meta name="description" content="<?= h($page_desc ?? $_site_tagline) ?>">
<meta name="keywords" content="<?= h(setting('meta_keywords','नेपाल समाचार,nepal news')) ?>">
<meta property="og:title"       content="<?= h($page_title ?? $_site_name) ?>">
<meta property="og:description" content="<?= h($page_desc ?? $_site_tagline) ?>">
<meta property="og:type"        content="website">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/assets/style.css">
<script src="https://cdn.tailwindcss.com?plugins=typography"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<style>
  :root {
    --c-primary:    <?= h($_primary) ?>;
    --c-nav-bg:     <?= h($_nav_color) ?>;
    --c-footer-bg:  <?= h($_nav_color) ?>;
    --c-primary-lt: <?= h(accent_color()) ?>;
  }
  [x-cloak]{display:none!important}
</style>
<?php if (setting('google_analytics')): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= h(setting('google_analytics')) ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?= h(setting('google_analytics')) ?>');</script>
<?php endif; ?>
</head>
<body class="min-h-screen">

<!-- Reading progress bar (articles only) -->
<div id="read-prog" class="reading-progress"></div>

<!-- ── Top utility bar ── -->
<div class="top-utility-bar">
  <div class="max-w-7xl mx-auto px-4 flex items-center justify-between">
    <span class="bs-date">📅 <?= bs_date_today() ?></span>
    <div class="flex items-center gap-1">
      <?php if (setting('epaper_url','')): ?>
      <a href="<?= h(setting('epaper_url','#')) ?>" target="_blank">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9"/>
        </svg>
        ePaper
      </a>
      <?php endif; ?>
      <?php if (setting('social_facebook','')): ?>
      <a href="<?= h(setting('social_facebook','')) ?>" target="_blank" rel="noopener" title="Facebook">
        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
        FB
      </a>
      <?php endif; ?>
      <?php if (setting('social_youtube','')): ?>
      <a href="<?= h(setting('social_youtube','')) ?>" target="_blank" rel="noopener" title="YouTube">
        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 001.95-1.96A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon fill="var(--c-nav-bg,#7F1D1D)" points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
        YouTube
      </a>
      <?php endif; ?>
      <a href="/search" title="खोज्नुस्">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
        खोज
      </a>
      <?php if (is_admin()): ?>
        <a href="/admin" style="color:var(--c-primary-lt);font-weight:700">⚙ Admin</a>
      <?php else: ?>
        <a href="/admin/login">लगइन</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ── Sticky header wrapper ── -->
<div class="header-sticky-wrap" :class="scrolled ? 'scrolled' : ''">

  <!-- Header banner ad (above header, non-sticky) -->
  <?php
  $_header_ads = get_active_ads('header-banner');
  if (!empty($_header_ads)): ?>
  <div class="ads-header-banner">
    <div class="max-w-7xl mx-auto px-4 flex justify-center gap-4">
      <?php foreach ($_header_ads as $_had): echo render_ad($_had); endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Site header -->
  <header class="site-header">
    <div class="max-w-7xl mx-auto px-4">
      <div class="flex items-center justify-between gap-4">

        <!-- Logo -->
        <a href="/" class="logo-wrap flex-shrink-0">
          <?php if ($_logo_url): ?>
            <img src="<?= h($_logo_url) ?>" alt="<?= h($_site_name) ?>" class="logo-img">
          <?php else: ?>
            <span class="logo-text"><?= h($_logo_text) ?></span>
            <span class="logo-tagline"><?= h($_site_tagline) ?></span>
          <?php endif; ?>
        </a>

        <!-- Right controls -->
        <div class="flex items-center gap-3 flex-wrap justify-end">
          <!-- Search button -->
          <button @click="searchOpen=true"
            class="flex items-center gap-2 px-3 py-2 rounded-full text-sm font-semibold transition-all"
            style="background:var(--c-tag-bg);color:var(--c-primary-lt);border:none;cursor:pointer;font-family:inherit">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            <span class="hidden sm:inline">खोज्नुस्</span>
          </button>

          <!-- Dark mode toggle -->
          <button class="dark-toggle" @click="darkMode=!darkMode">
            <span x-show="!darkMode">🌙 <span class="hidden sm:inline">Dark</span></span>
            <span x-show="darkMode" x-cloak>☀️ <span class="hidden sm:inline">Light</span></span>
          </button>
        </div>
      </div>
    </div>
  </header>

  <!-- Breaking news ticker -->
  <?php
  $_ticker = get_articles(['status'=>'published','limit'=>12,'order'=>'a.published_at DESC']);
  if ($_ticker): ?>
  <div class="ticker-bar">
    <div class="max-w-7xl mx-auto px-4 flex items-center overflow-hidden">
      <span class="ticker-label flex-shrink-0"><?= h($_ticker_label) ?> 🔴</span>
      <div class="overflow-hidden flex-1">
        <span class="ticker-scroll">
          <?php foreach ($_ticker as $i => $_t): ?>
            <?= $i>0 ? '&nbsp;&nbsp;&bull;&nbsp;&nbsp;' : '' ?>
            <a href="/article/<?= h($_t['slug']) ?>" class="hover:underline"><?= h($_t['title']) ?></a>
          <?php endforeach; ?>
        </span>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Main nav -->
  <nav class="main-nav" x-data="{open:false}">
    <div class="max-w-7xl mx-auto px-4">
      <div class="flex items-center">
        <div class="hidden md:flex flex-wrap flex-1">
          <a href="/" class="<?= $_current_path==='/'?'active':'' ?>">गृहपृष्ठ</a>
          <?php foreach ($_categories as $_nc): ?>
            <a href="/category/<?= h($_nc['slug']) ?>"
               class="<?= str_contains($_current_path, $_nc['slug'])?'active':'' ?>">
              <?= h($_nc['name_np'] ?: $_nc['name']) ?>
            </a>
          <?php endforeach; ?>
        </div>
        <!-- Mobile hamburger -->
        <button @click="open=!open" class="md:hidden text-white p-2 ml-auto" style="background:none;border:none;cursor:pointer" aria-label="Menu">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" x-show="!open"/>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" x-show="open" x-cloak/>
          </svg>
        </button>
      </div>
      <!-- Mobile menu -->
      <div x-show="open" x-transition class="md:hidden pb-3 border-t border-white border-opacity-20 mt-1">
        <a href="/" class="block px-2 py-2 text-white text-sm font-semibold hover:bg-white hover:bg-opacity-10">गृहपृष्ठ</a>
        <?php foreach ($_categories as $_nc): ?>
          <a href="/category/<?= h($_nc['slug']) ?>"
             class="block px-2 py-2 text-white text-sm font-semibold hover:bg-white hover:bg-opacity-10">
            <?= isset($cat_icons[$_nc['slug']]) ? $cat_icons[$_nc['slug']] . ' ' : '' ?>
            <?= h($_nc['name_np'] ?: $_nc['name']) ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </nav>

  <!-- Category icon strip -->
  <div class="cat-strip">
    <div class="max-w-7xl mx-auto px-4 flex">
      <?php foreach ($_categories as $_cs): ?>
        <a href="/category/<?= h($_cs['slug']) ?>" class="cat-pill">
          <span class="cat-icon" style="background:<?= h($_cs['color']?:accent_color()) ?>22;color:<?= h($_cs['color']?:accent_color()) ?>">
            <?= $cat_icons[$_cs['slug']] ?? '📰' ?>
          </span>
          <?= h($_cs['name_np'] ?: $_cs['name']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

</div><!-- /sticky wrap -->

<!-- Search overlay -->
<div x-show="searchOpen" x-cloak
     class="search-overlay"
     @keydown.escape.window="searchOpen=false"
     @click.self="searchOpen=false"
     x-transition:enter="transition ease-out duration-200"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100"
     x-transition:leave="transition ease-in duration-150"
     x-transition:leave-start="opacity-100"
     x-transition:leave-end="opacity-0">
  <div class="search-overlay-box" @click.stop>
    <div class="flex items-center justify-between mb-4">
      <h2 class="text-lg font-bold">समाचार खोज्नुस्</h2>
      <button @click="searchOpen=false" class="text-2xl leading-none font-bold" style="background:none;border:none;cursor:pointer;color:var(--c-muted)">&times;</button>
    </div>
    <form method="GET" action="/search">
      <input type="search" name="q" class="search-overlay-input"
             placeholder="नेपाली वा English मा खोज्नुस्..."
             x-init="$nextTick(()=>{ if($el.closest('[x-show]').__x) $el.focus() })"
             autofocus>
      <div class="flex gap-2 mt-3">
        <button type="submit" class="btn btn-primary flex-1 justify-center">
          🔍 खोज्नुस्
        </button>
        <button type="button" @click="searchOpen=false" class="btn btn-secondary">रद्द</button>
      </div>
    </form>
  </div>
</div>

<!-- Back to top button -->
<button class="back-to-top" :class="backTop ? '' : 'hidden'" @click="window.scrollTo({top:0,behavior:'smooth'})" title="माथि जानुस्">
  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 15l7-7 7 7"/>
  </svg>
</button>

<!-- Main content start -->
<main class="max-w-7xl mx-auto px-4 py-6">
