<?php
admin_check();
$id       = (int)($_GET['id'] ?? 0);
$article  = $id ? get_article_by_id($id) : null;
$cats     = get_categories();
$authors  = get_authors();
$all_tags = get_tags();
$sel_tags = $article ? array_column($article['tags'], 'id') : [];
$is_edit  = $article !== null;
$form_title = $is_edit ? 'लेख सम्पादन' : 'नयाँ लेख';

// Default values
$d = [
    'title'       => $article['title']       ?? '',
    'title_np'    => $article['title_np']    ?? '',
    'slug'        => $article['slug']        ?? '',
    'summary'     => $article['summary']     ?? '',
    'summary_np'  => $article['summary_np']  ?? '',
    'content'     => $article['content']     ?? '',
    'content_np'  => $article['content_np']  ?? '',
    'language'    => $article['language']    ?? 'np',
    'status'      => $article['status']      ?? 'draft',
    'featured'    => $article['featured']    ?? 0,
    'image_url'   => $article['image_url']   ?? '',
    'category_id' => $article['category_id'] ?? '',
    'author_id'   => $article['author_id']   ?? '',
    'published_at'=> $article['published_at'] ?? date('Y-m-d H:i:s'),
];

admin_html_start($form_title);
admin_sidebar('articles');
?>
<div class="admin-content">
<?php admin_topbar($form_title); ?>
<div class="p-6">
<?php admin_flash(); ?>
<form method="POST" action="/admin/articles/save"
      x-data="{
        title: <?= json_encode($d['title']) ?>,
        slug: <?= json_encode($d['slug']) ?>,
        autoSlug: <?= $is_edit ? 'false' : 'true' ?>,
        makeSlug(t) {
          return t.toLowerCase()
            .replace(/[^\w\s-]/g,'')
            .replace(/[\s_]+/g,'-')
            .replace(/^-+|-+$/g,'') || 'article';
        }
      }">
  <?= csrf_field() ?>
  <?php if ($is_edit): ?><input type="hidden" name="id" value="<?= $id ?>"><?php endif; ?>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Main -->
    <div class="lg:col-span-2 space-y-4">
      <div class="form-group">
        <label class="form-label">शीर्षक (प्राथमिक) <span class="text-red-500">*</span></label>
        <input type="text" name="title" class="form-control" required
               placeholder="लेखको मुख्य शीर्षक"
               x-model="title"
               @input="if(autoSlug) slug=makeSlug(title)"
               value="<?= h($d['title']) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">शीर्षक (वैकल्पिक — अर्को भाषा)</label>
        <input type="text" name="title_np" class="form-control"
               placeholder="Optional second-language title"
               value="<?= h($d['title_np']) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">URL Slug</label>
        <div class="flex gap-2">
          <input type="text" name="slug" class="form-control flex-1" required
                 x-model="slug" @focus="autoSlug=false"
                 placeholder="url-friendly-slug">
          <button type="button" class="btn btn-secondary btn-sm"
                  @click="slug=makeSlug(title);autoSlug=false">Auto</button>
        </div>
        <p class="form-hint">URL: /article/<span x-text="slug || 'slug'"></span></p>
      </div>
      <div class="form-group">
        <label class="form-label">सारांश (नेपाली) <span class="text-red-500">*</span></label>
        <textarea name="summary" class="form-control" rows="3" required
                  placeholder="संक्षिप्त विवरण..."><?= h($d['summary']) ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">सारांश (English)</label>
        <textarea name="summary_np" class="form-control" rows="2"
                  placeholder="Brief summary in English..."><?= h($d['summary_np']) ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">लेखको विषयवस्तु (प्राथमिक) <span class="text-red-500">*</span></label>
        <textarea name="content" class="form-control" rows="16" required
                  placeholder="HTML वा plain text लेख्नुस्..."><?= h($d['content']) ?></textarea>
        <p class="form-hint">HTML tags प्रयोग गर्न मिल्छ: &lt;p&gt; &lt;h2&gt; &lt;h3&gt; &lt;ul&gt; &lt;li&gt; &lt;blockquote&gt; &lt;strong&gt; &lt;em&gt;</p>
      </div>
      <div class="form-group">
        <label class="form-label">लेखको विषयवस्तु (अर्को भाषा / English)</label>
        <textarea name="content_np" class="form-control" rows="8"
                  placeholder="Optional second language content..."><?= h($d['content_np']) ?></textarea>
      </div>
    </div>

    <!-- Sidebar settings -->
    <div class="space-y-4">
      <div class="stat-card space-y-4">
        <h3 class="font-bold text-sm" style="color:var(--c-text)">प्रकाशन सेटिङ्स</h3>
        <div class="form-group">
          <label class="form-label">स्थिति</label>
          <select name="status" class="form-control">
            <option value="draft"     <?= $d['status']==='draft'?'selected':'' ?>>ड्राफ्ट</option>
            <option value="published" <?= $d['status']==='published'?'selected':'' ?>>प्रकाशित</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">भाषा</label>
          <select name="language" class="form-control">
            <option value="np" <?= $d['language']==='np'?'selected':'' ?>>नेपाली</option>
            <option value="en" <?= $d['language']==='en'?'selected':'' ?>>English</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">प्रकाशन मिति</label>
          <input type="datetime-local" name="published_at" class="form-control"
                 value="<?= h(date('Y-m-d\TH:i', strtotime($d['published_at'] ?: 'now'))) ?>">
        </div>
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" name="featured" value="1" <?= $d['featured']?'checked':'' ?> class="rounded">
          <span class="text-sm font-semibold">⭐ Featured लेख</span>
        </label>
      </div>

      <div class="stat-card space-y-4">
        <h3 class="font-bold text-sm" style="color:var(--c-text)">वर्गीकरण</h3>
        <div class="form-group">
          <label class="form-label">श्रेणी <span class="text-red-500">*</span></label>
          <select name="category_id" class="form-control" required>
            <option value="">-- श्रेणी छान्नुस् --</option>
            <?php foreach ($cats as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= $d['category_id']==$cat['id']?'selected':'' ?>>
              <?= h($cat['name_np'] ?: $cat['name']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">लेखक <span class="text-red-500">*</span></label>
          <select name="author_id" class="form-control" required>
            <option value="">-- लेखक छान्नुस् --</option>
            <?php foreach ($authors as $author): ?>
            <option value="<?= $author['id'] ?>" <?= $d['author_id']==$author['id']?'selected':'' ?>>
              <?= h($author['name']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">ट्यागहरू</label>
          <div class="flex flex-wrap gap-2">
            <?php foreach ($all_tags as $tag): ?>
            <label class="flex items-center gap-1 text-xs cursor-pointer">
              <input type="checkbox" name="tag_ids[]" value="<?= $tag['id'] ?>"
                     <?= in_array($tag['id'], $sel_tags)?'checked':'' ?>>
              <?= h($tag['name']) ?>
            </label>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="stat-card">
        <h3 class="font-bold text-sm mb-3" style="color:var(--c-text)">फिचर्ड तस्वीर</h3>
        <div class="form-group">
          <label class="form-label">Image URL</label>
          <input type="url" name="image_url" class="form-control text-sm"
                 placeholder="https://example.com/image.jpg"
                 value="<?= h($d['image_url']) ?>">
          <p class="form-hint">बाह्य URL छान्नुस् वा खाली छोड्नुस्</p>
        </div>
        <?php if ($d['image_url']): ?>
        <img src="<?= h($d['image_url']) ?>" alt="" class="mt-2 rounded w-full object-cover" style="max-height:120px">
        <?php endif; ?>
      </div>

      <div class="flex gap-2">
        <button type="submit" class="btn btn-primary flex-1 justify-center">
          <?= $is_edit ? 'अपडेट' : 'प्रकाशित' ?>
        </button>
        <a href="/admin/articles" class="btn btn-secondary">रद्द</a>
      </div>
    </div>
  </div>
</form>
</div>
</div>
</body></html>
