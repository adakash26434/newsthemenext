<?php
admin_check();
$s = get_all_settings();
admin_html_start('साइट सेटिङ्स');
admin_sidebar('settings');
?>
<div class="admin-content">
<?php admin_topbar('साइट सेटिङ्स'); ?>
<div class="p-6">
<?php admin_flash(); ?>

<form method="POST" action="/admin/settings/save">
  <?= csrf_field() ?>
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

    <!-- Site Identity -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        🏠 साइट पहिचान
      </h2>
      <div class="form-group">
        <label class="form-label">साइट नाम (नेपाली) *</label>
        <input type="text" name="site_name" class="form-control"
               value="<?= h($s['site_name']??'') ?>" placeholder="न्यूज पोर्टल नेपाल" required>
      </div>
      <div class="form-group">
        <label class="form-label">साइट नाम (English)</label>
        <input type="text" name="site_name_en" class="form-control"
               value="<?= h($s['site_name_en']??'') ?>" placeholder="Nepal News Portal">
      </div>
      <div class="form-group">
        <label class="form-label">ट्याग लाइन</label>
        <input type="text" name="site_tagline" class="form-control"
               value="<?= h($s['site_tagline']??'') ?>" placeholder="नेपालको विश्वसनीय समाचार पोर्टल">
      </div>
      <div class="form-group">
        <label class="form-label">Logo Text (Navbar)</label>
        <input type="text" name="site_logo_text" class="form-control"
               value="<?= h($s['site_logo_text']??'') ?>" placeholder="न्यूज पोर्टल">
        <p class="form-hint">Logo image नभएमा यो text देखिन्छ।</p>
      </div>
      <div class="form-group">
        <label class="form-label">Logo Image URL</label>
        <input type="url" name="site_logo_url" class="form-control"
               value="<?= h($s['site_logo_url']??'') ?>" placeholder="https://example.com/logo.png">
        <p class="form-hint">खाली छोड्नुस् भने Logo Text देखिन्छ।</p>
        <?php if (!empty($s['site_logo_url'])): ?>
          <img src="<?= h($s['site_logo_url']) ?>" alt="Current Logo" class="mt-2 rounded" style="max-height:48px;max-width:200px">
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label class="form-label">Ticker Label</label>
        <input type="text" name="ticker_label" class="form-control"
               value="<?= h($s['ticker_label']??'ताजा खबर') ?>" placeholder="ताजा खबर">
      </div>
      <div class="form-group">
        <label class="form-label">ePaper URL</label>
        <input type="url" name="epaper_url" class="form-control"
               value="<?= h($s['epaper_url']??'') ?>" placeholder="https://epaper.example.com">
        <p class="form-hint">Top bar मा ePaper link देखाउन। खाली छोड्नुस् भने लुकाइन्छ।</p>
      </div>
    </div>

    <!-- Colors -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        🎨 थीम रंगहरू
      </h2>
      <div class="form-group">
        <label class="form-label">Primary Color</label>
        <div class="flex gap-3 items-center">
          <input type="color" name="primary_color" class="rounded cursor-pointer" style="width:42px;height:42px;border:1px solid var(--c-border)"
                 value="<?= h($s['primary_color']??'#7F1D1D') ?>">
          <input type="text" id="primary_color_text" class="form-control" style="max-width:120px"
                 value="<?= h($s['primary_color']??'#7F1D1D') ?>" placeholder="#7F1D1D"
                 oninput="document.querySelector('[name=primary_color]').value=this.value">
        </div>
        <p class="form-hint">Logo, Sidebar बाएँ border, Heading रंगको लागि</p>
      </div>
      <div class="form-group">
        <label class="form-label">Nav/Footer Color</label>
        <div class="flex gap-3 items-center">
          <input type="color" name="nav_color" class="rounded cursor-pointer" style="width:42px;height:42px;border:1px solid var(--c-border)"
                 value="<?= h($s['nav_color']??'#7F1D1D') ?>">
          <input type="text" class="form-control" style="max-width:120px"
                 value="<?= h($s['nav_color']??'#7F1D1D') ?>" placeholder="#7F1D1D"
                 oninput="document.querySelector('[name=nav_color]').value=this.value">
        </div>
        <p class="form-hint">Nav bar, Admin sidebar, Footer बारको रंग</p>
      </div>
      <div class="form-group">
        <label class="form-label">Accent Color</label>
        <div class="flex gap-3 items-center">
          <input type="color" name="accent_color" class="rounded cursor-pointer" style="width:42px;height:42px;border:1px solid var(--c-border)"
                 value="<?= h($s['accent_color']??'#991B1B') ?>">
          <input type="text" class="form-control" style="max-width:120px"
                 value="<?= h($s['accent_color']??'#991B1B') ?>" placeholder="#991B1B"
                 oninput="document.querySelector('[name=accent_color]').value=this.value">
        </div>
        <p class="form-hint">Badges, links, hover states को रंग</p>
      </div>

      <div class="pt-2">
        <p class="text-xs font-semibold mb-2" style="color:var(--c-muted)">Color Preview</p>
        <div class="flex gap-2 flex-wrap">
          <div class="px-3 py-1 rounded text-xs font-bold text-white" style="background:<?= h($s['primary_color']??'#7F1D1D') ?>">Primary</div>
          <div class="px-3 py-1 rounded text-xs font-bold text-white" style="background:<?= h($s['nav_color']??'#7F1D1D') ?>">Nav/Footer</div>
          <div class="px-3 py-1 rounded text-xs font-bold text-white" style="background:<?= h($s['accent_color']??'#991B1B') ?>">Accent</div>
        </div>
      </div>
    </div>

    <!-- Contact Info -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        📞 सम्पर्क विवरण
      </h2>
      <div class="form-group">
        <label class="form-label">इमेल</label>
        <input type="email" name="contact_email" class="form-control"
               value="<?= h($s['contact_email']??'') ?>" placeholder="info@newsportal.com.np">
      </div>
      <div class="form-group">
        <label class="form-label">फोन</label>
        <input type="text" name="contact_phone" class="form-control"
               value="<?= h($s['contact_phone']??'') ?>" placeholder="+977-01-xxxxxxx">
      </div>
      <div class="form-group">
        <label class="form-label">ठेगाना</label>
        <input type="text" name="contact_address" class="form-control"
               value="<?= h($s['contact_address']??'') ?>" placeholder="काठमाडौं, नेपाल">
      </div>
      <div class="form-group">
        <label class="form-label">Footer परिचय</label>
        <textarea name="footer_about" class="form-control" rows="3"
                  placeholder="साइटको संक्षिप्त परिचय..."><?= h($s['footer_about']??'') ?></textarea>
      </div>
    </div>

    <!-- Social Links -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        📱 सामाजिक सञ्जाल
      </h2>
      <div class="form-group">
        <label class="form-label">Facebook URL</label>
        <input type="url" name="social_facebook" class="form-control"
               value="<?= h($s['social_facebook']??'') ?>" placeholder="https://facebook.com/yourpage">
      </div>
      <div class="form-group">
        <label class="form-label">Twitter/X URL</label>
        <input type="url" name="social_twitter" class="form-control"
               value="<?= h($s['social_twitter']??'') ?>" placeholder="https://twitter.com/yourhandle">
      </div>
      <div class="form-group">
        <label class="form-label">YouTube URL</label>
        <input type="url" name="social_youtube" class="form-control"
               value="<?= h($s['social_youtube']??'') ?>" placeholder="https://youtube.com/yourchannel">
      </div>
      <div class="form-group">
        <label class="form-label">Instagram URL</label>
        <input type="url" name="social_instagram" class="form-control"
               value="<?= h($s['social_instagram']??'') ?>" placeholder="https://instagram.com/yourprofile">
      </div>
    </div>

    <!-- SEO & Analytics -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        🔍 SEO र Analytics
      </h2>
      <div class="form-group">
        <label class="form-label">Meta Keywords</label>
        <input type="text" name="meta_keywords" class="form-control"
               value="<?= h($s['meta_keywords']??'') ?>" placeholder="नेपाल समाचार, ताजा खबर, nepal news">
        <p class="form-hint">कमाले छुट्याएर लेख्नुस्</p>
      </div>
      <div class="form-group">
        <label class="form-label">Google Analytics ID</label>
        <input type="text" name="google_analytics" class="form-control"
               value="<?= h($s['google_analytics']??'') ?>" placeholder="G-XXXXXXXXXX">
        <p class="form-hint">Google Analytics 4 Measurement ID</p>
      </div>
    </div>

    <!-- Admin Credentials -->
    <div class="stat-card space-y-4">
      <h2 class="font-bold text-sm pb-2" style="border-bottom:1px solid var(--c-admin-border)">
        🔐 Admin Credentials
      </h2>
      <div class="p-3 rounded text-xs mb-2" style="background:#FEF3C7;color:#92400E;border:1px solid #FCD34D">
        ⚠️ यहाँ परिवर्तन गरेपछि नयाँ credentials सम्झिनुस्। Password हराएमा database बाट reset गर्नुपर्छ।
      </div>
      <div class="form-group">
        <label class="form-label">Admin Username</label>
        <input type="text" name="admin_username" class="form-control"
               value="<?= h($s['admin_username']??'admin') ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Admin Password (नयाँ)</label>
        <input type="password" name="admin_password_new" class="form-control"
               placeholder="खाली छोड्नुस् भने परिवर्तन हुँदैन">
        <p class="form-hint">परिवर्तन नगर्ने हो भने खाली छाड्नुस्</p>
      </div>
      <div class="form-group">
        <label class="form-label">Password Confirm</label>
        <input type="password" name="admin_password_confirm" class="form-control"
               placeholder="माथिकै Password दोहोर्याउनुस्">
      </div>
    </div>

  </div>

  <div class="mt-6 flex gap-3">
    <button type="submit" class="btn btn-primary px-8">सेटिङ्स सेभ गर्नुस्</button>
    <a href="/admin" class="btn btn-secondary">रद्द</a>
  </div>
</form>

</div>
</div>
</body></html>
