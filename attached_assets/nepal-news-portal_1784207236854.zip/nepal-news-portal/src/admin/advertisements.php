<?php
admin_check();
$ads = db_fetchAll("SELECT * FROM advertisements ORDER BY position ASC, sort_order ASC, id ASC");
$positions = [
    'header-banner'  => 'Header Banner (शीर्षमा)',
    'sidebar-top'    => 'Sidebar माथि',
    'sidebar-bottom' => 'Sidebar तल',
    'article-middle' => 'लेख बीचमा',
    'article-bottom' => 'लेख तलमा',
];
$edit_id = (int)($_GET['id'] ?? 0);
$edit_ad = $edit_id ? db_fetch("SELECT * FROM advertisements WHERE id=?",[$edit_id]) : null;
admin_html_start('विज्ञापन');
admin_sidebar('advertisements');
?>
<div class="admin-content">
<?php admin_topbar('विज्ञापन व्यवस्थापन'); ?>
<div class="p-6">
<?php admin_flash(); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <!-- Ad list -->
  <div class="lg:col-span-2">
    <?php foreach ($positions as $pos_key => $pos_label): ?>
    <?php $pos_ads = array_filter($ads, fn($a) => $a['position'] === $pos_key); ?>
    <div class="mb-6">
      <div class="section-heading mb-3">
        <span><?= h($pos_label) ?></span>
        <a href="/admin/advertisements?action=new&position=<?= h($pos_key) ?>" class="btn btn-primary btn-sm">+ थप्नुस्</a>
      </div>
      <?php if (empty($pos_ads)): ?>
        <p class="text-xs py-2 px-3 rounded" style="background:var(--c-admin-surface);border:1px solid var(--c-admin-border);color:var(--c-muted)">
          यस स्थानमा कुनै विज्ञापन छैन।
        </p>
      <?php else: ?>
      <table class="data-table">
        <thead><tr><th>शीर्षक</th><th>प्रकार</th><th>Link</th><th>क्रम</th><th>स्थिति</th><th>कार्य</th></tr></thead>
        <tbody>
          <?php foreach ($pos_ads as $ad): ?>
          <tr>
            <td class="font-semibold text-sm"><?= h($ad['title']) ?></td>
            <td>
              <span class="badge <?= $ad['type']==='image'?'badge-blue':($ad['type']==='code'?'badge-gray':'badge-green') ?>">
                <?= h(strtoupper($ad['type'])) ?>
              </span>
            </td>
            <td class="text-xs" style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
              <?= $ad['link_url'] ? '<a href="' . h($ad['link_url']) . '" target="_blank" class="hover:underline" style="color:var(--c-primary-lt)">' . h(mb_substr($ad['link_url'],0,30)) . '</a>' : '—' ?>
            </td>
            <td class="text-sm"><?= h($ad['sort_order']) ?></td>
            <td>
              <form method="POST" action="/admin/advertisements/toggle" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                <button type="submit" class="badge <?= $ad['active']?'badge-green':'badge-gray' ?>" style="cursor:pointer;border:none;font-family:inherit">
                  <?= $ad['active']?'सक्रिय':'निष्क्रिय' ?>
                </button>
              </form>
            </td>
            <td>
              <div class="actions">
                <a href="/admin/advertisements?action=edit&id=<?= $ad['id'] ?>" class="btn btn-secondary btn-sm">सम्पादन</a>
                <form method="POST" action="/admin/advertisements/delete" onsubmit="return confirm('यो विज्ञापन मेटाउने?')">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">मेट्नुस्</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Add/Edit form -->
  <div class="stat-card" x-data="{adType: <?= json_encode($edit_ad['type'] ?? ($_GET['type'] ?? 'image')) ?>}">
    <h2 class="font-bold text-sm mb-4"><?= $edit_ad ? 'विज्ञापन सम्पादन' : 'नयाँ विज्ञापन' ?></h2>
    <form method="POST" action="/admin/advertisements/save">
      <?= csrf_field() ?>
      <?php if ($edit_ad): ?><input type="hidden" name="id" value="<?= $edit_ad['id'] ?>"><?php endif; ?>

      <div class="form-group">
        <label class="form-label">शीर्षक *</label>
        <input type="text" name="title" class="form-control" required
               value="<?= h($edit_ad['title']??'') ?>" placeholder="विज्ञापनको नाम">
      </div>

      <div class="form-group">
        <label class="form-label">स्थान *</label>
        <select name="position" class="form-control">
          <?php $def_pos = $_GET['position'] ?? ($edit_ad['position'] ?? 'sidebar-top'); ?>
          <?php foreach ($positions as $pk => $pl): ?>
            <option value="<?= h($pk) ?>" <?= $def_pos===$pk?'selected':'' ?>><?= h($pl) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">प्रकार *</label>
        <select name="type" class="form-control" x-model="adType">
          <option value="image"  <?= ($edit_ad['type']??'image')==='image'?'selected':'' ?>>Image</option>
          <option value="code"   <?= ($edit_ad['type']??'')==='code'?'selected':'' ?>>HTML/Script Code</option>
          <option value="text"   <?= ($edit_ad['type']??'')==='text'?'selected':'' ?>>Text</option>
        </select>
      </div>

      <div class="form-group" x-show="adType==='image'">
        <label class="form-label">Image URL</label>
        <input type="url" name="image_url" class="form-control"
               value="<?= h($edit_ad['image_url']??'') ?>" placeholder="https://example.com/banner.jpg">
        <?php if (!empty($edit_ad['image_url'])): ?>
          <img src="<?= h($edit_ad['image_url']) ?>" alt="" class="mt-2 rounded" style="max-height:60px;max-width:100%">
        <?php endif; ?>
      </div>

      <div class="form-group" x-show="adType==='code'">
        <label class="form-label">HTML/Script Code</label>
        <textarea name="code" class="form-control text-xs" rows="5"
                  placeholder="&lt;script&gt;...&lt;/script&gt; वा HTML"><?= h($edit_ad['code']??'') ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label">Link URL (Click destination)</label>
        <input type="url" name="link_url" class="form-control"
               value="<?= h($edit_ad['link_url']??'') ?>" placeholder="https://advertiser.com">
      </div>

      <div class="form-group">
        <label class="form-label">क्रम (Sort order)</label>
        <input type="number" name="sort_order" class="form-control" min="0"
               value="<?= h($edit_ad['sort_order']??0) ?>">
      </div>

      <label class="flex items-center gap-2 mb-4 cursor-pointer">
        <input type="checkbox" name="active" value="1" <?= ($edit_ad['active']??1)?'checked':'' ?>>
        <span class="text-sm font-semibold">सक्रिय छ</span>
      </label>

      <div class="flex gap-2">
        <button type="submit" class="btn btn-primary flex-1 justify-center"><?= $edit_ad?'अपडेट':'थप्नुस्' ?></button>
        <?php if ($edit_ad): ?><a href="/admin/advertisements" class="btn btn-secondary">रद्द</a><?php endif; ?>
      </div>
    </form>
  </div>
</div>
</div>
</div>
</body></html>
