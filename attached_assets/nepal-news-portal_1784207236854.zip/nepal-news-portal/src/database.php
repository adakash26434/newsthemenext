<?php
require_once __DIR__ . '/config.php';

function get_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    if (!is_dir(DATA_DIR)) mkdir(DATA_DIR, 0755, true);
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo->exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;");
    return $pdo;
}

// ── Generic helpers ────────────────────────────────────────
function db_query(string $sql, array $params = []): PDOStatement {
    $stmt = get_db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}
function db_fetch(string $sql, array $params = []): ?array {
    return db_query($sql, $params)->fetch() ?: null;
}
function db_fetchAll(string $sql, array $params = []): array {
    return db_query($sql, $params)->fetchAll();
}
function db_insert(string $sql, array $params = []): int {
    db_query($sql, $params);
    return (int) get_db()->lastInsertId();
}
function db_count(string $sql, array $params = []): int {
    return (int) db_query($sql, $params)->fetchColumn();
}

// ── Settings ───────────────────────────────────────────────
function get_all_settings(): array {
    static $cache = null;
    if ($cache !== null) return $cache;
    try {
        $rows  = db_fetchAll("SELECT key, value FROM settings");
        $cache = [];
        foreach ($rows as $r) $cache[$r['key']] = $r['value'];
    } catch (Exception $e) { $cache = []; }
    return $cache;
}
function setting(string $key, string $default = ''): string {
    return get_all_settings()[$key] ?? $default;
}
function save_setting(string $key, string $value): void {
    db_query("INSERT INTO settings (key,value,updated_at) VALUES (?,?,datetime('now'))
              ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
        [$key, $value]);
}

// ── Articles ───────────────────────────────────────────────
function get_articles(array $opts = []): array {
    $where = ['1=1']; $params = [];
    if (!empty($opts['status']))        { $where[] = 'a.status = ?';        $params[] = $opts['status']; }
    if (!empty($opts['featured']))      { $where[] = 'a.featured = 1'; }
    if (!empty($opts['category_id']))   { $where[] = 'a.category_id = ?';   $params[] = $opts['category_id']; }
    if (!empty($opts['category_slug'])) { $where[] = 'c.slug = ?';          $params[] = $opts['category_slug']; }
    if (!empty($opts['author_id']))     { $where[] = 'a.author_id = ?';     $params[] = $opts['author_id']; }
    if (!empty($opts['author_slug']))   { $where[] = 'au.slug = ?';         $params[] = $opts['author_slug']; }
    if (!empty($opts['language']))      { $where[] = 'a.language = ?';      $params[] = $opts['language']; }
    if (!empty($opts['search'])) {
        $where[] = '(a.title LIKE ? OR a.title_np LIKE ? OR a.summary LIKE ? OR a.content LIKE ?)';
        $s = '%' . $opts['search'] . '%';
        $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
    }
    $limit  = (int)($opts['limit']  ?? ARTICLES_PER_PAGE);
    $offset = (int)($opts['offset'] ?? 0);
    $order  = $opts['order'] ?? 'a.published_at DESC, a.created_at DESC';
    $ws     = implode(' AND ', $where);
    return db_fetchAll(
        "SELECT a.*, c.name AS category_name, c.name_np AS category_name_np,
                c.slug AS category_slug, c.color AS category_color,
                au.name AS author_name, au.slug AS author_slug
         FROM articles a
         JOIN categories c  ON c.id = a.category_id
         JOIN authors    au ON au.id = a.author_id
         WHERE $ws ORDER BY $order LIMIT $limit OFFSET $offset",
        $params);
}

function count_articles(array $opts = []): int {
    $where = ['1=1']; $params = [];
    if (!empty($opts['status']))        { $where[] = 'a.status = ?';        $params[] = $opts['status']; }
    if (!empty($opts['category_slug'])) { $where[] = 'c.slug = ?';          $params[] = $opts['category_slug']; }
    if (!empty($opts['author_slug']))   { $where[] = 'au.slug = ?';         $params[] = $opts['author_slug']; }
    if (!empty($opts['language']))      { $where[] = 'a.language = ?';      $params[] = $opts['language']; }
    if (!empty($opts['search'])) {
        $where[] = '(a.title LIKE ? OR a.title_np LIKE ? OR a.summary LIKE ?)';
        $s = '%' . $opts['search'] . '%';
        $params[] = $s; $params[] = $s; $params[] = $s;
    }
    $ws = implode(' AND ', $where);
    return db_count(
        "SELECT COUNT(*) FROM articles a
         JOIN categories c ON c.id=a.category_id
         JOIN authors au ON au.id=a.author_id
         WHERE $ws", $params);
}

function get_popular_articles(int $limit = 6): array {
    return db_fetchAll(
        "SELECT a.*, c.name AS category_name, c.name_np AS category_name_np,
                c.slug AS category_slug, c.color AS category_color,
                au.name AS author_name, au.slug AS author_slug
         FROM articles a
         JOIN categories c  ON c.id = a.category_id
         JOIN authors    au ON au.id = a.author_id
         WHERE a.status='published'
         ORDER BY a.views DESC, a.published_at DESC
         LIMIT ?",
        [$limit]);
}

function get_article_by_slug(string $slug): ?array {
    $a = db_fetch(
        "SELECT a.*, c.name AS category_name, c.name_np AS category_name_np,
                c.slug AS category_slug, c.color AS category_color,
                au.name AS author_name, au.name_np AS author_name_np,
                au.slug AS author_slug, au.bio AS author_bio, au.avatar_url AS author_avatar
         FROM articles a
         JOIN categories c  ON c.id = a.category_id
         JOIN authors    au ON au.id = a.author_id
         WHERE a.slug = ?", [$slug]);
    if (!$a) return null;
    $a['tags'] = db_fetchAll(
        "SELECT t.* FROM tags t JOIN article_tags at2 ON at2.tag_id=t.id WHERE at2.article_id=?",
        [$a['id']]);
    return $a;
}

function get_article_by_id(int $id): ?array {
    $a = db_fetch(
        "SELECT a.*, c.name AS category_name, c.slug AS category_slug,
                au.name AS author_name, au.slug AS author_slug
         FROM articles a
         JOIN categories c ON c.id=a.category_id
         JOIN authors au ON au.id=a.author_id
         WHERE a.id=?", [$id]);
    if (!$a) return null;
    $a['tags'] = db_fetchAll(
        "SELECT t.* FROM tags t JOIN article_tags at2 ON at2.tag_id=t.id WHERE at2.article_id=?",
        [$id]);
    return $a;
}

function increment_views(int $id): void {
    db_query("UPDATE articles SET views = views + 1 WHERE id = ?", [$id]);
}

function save_article(array $data, ?int $id = null): int {
    $cols = ['title','title_np','slug','content','content_np','summary','summary_np',
             'status','featured','image_url','language','category_id','author_id','published_at'];
    if ($id === null) {
        $fields = implode(',', $cols);
        $ph     = implode(',', array_fill(0, count($cols), '?'));
        $values = array_map(fn($c) => $data[$c] ?? null, $cols);
        $new_id = db_insert("INSERT INTO articles ($fields) VALUES ($ph)", $values);
    } else {
        $set    = implode(', ', array_map(fn($c) => "$c=?", $cols));
        $values = array_map(fn($c) => $data[$c] ?? null, $cols);
        $values[] = $id;
        db_query("UPDATE articles SET $set, updated_at=CURRENT_TIMESTAMP WHERE id=?", $values);
        $new_id = $id;
    }
    if ($id !== null) db_query("DELETE FROM article_tags WHERE article_id=?", [$new_id]);
    foreach ($data['tag_ids'] ?? [] as $tid) {
        db_query("INSERT OR IGNORE INTO article_tags (article_id,tag_id) VALUES (?,?)", [$new_id, $tid]);
    }
    return $new_id;
}

// ── Categories / Authors / Tags ────────────────────────────
function get_categories(): array {
    return db_fetchAll(
        "SELECT c.*, (SELECT COUNT(*) FROM articles a WHERE a.category_id=c.id AND a.status='published') AS article_count
         FROM categories c ORDER BY c.sort_order ASC, c.name ASC");
}
function get_authors(): array {
    return db_fetchAll("SELECT * FROM authors ORDER BY name");
}
function get_tags(): array {
    return db_fetchAll("SELECT * FROM tags ORDER BY name");
}

// ── Advertisements ─────────────────────────────────────────
function get_active_ads(string $position): array {
    return db_fetchAll(
        "SELECT * FROM advertisements WHERE position=? AND active=1 ORDER BY sort_order ASC, id ASC",
        [$position]);
}
function render_ad(array $ad): string {
    $out = '<div class="ad-slot" data-pos="' . htmlspecialchars($ad['position']) . '">';
    if ($ad['link_url']) $out .= '<a href="' . htmlspecialchars($ad['link_url']) . '" target="_blank" rel="noopener sponsored">';
    if ($ad['type'] === 'image' && $ad['image_url']) {
        $out .= '<img src="' . htmlspecialchars($ad['image_url']) . '" alt="' . htmlspecialchars($ad['title']) . '" loading="lazy" style="max-width:100%;display:block">';
    } elseif ($ad['type'] === 'code' && $ad['code']) {
        $out .= $ad['code'];
    } else {
        $out .= '<div class="ad-text-box p-3 text-center text-sm font-semibold">' . htmlspecialchars($ad['title']) . '</div>';
    }
    if ($ad['link_url']) $out .= '</a>';
    $out .= '</div>';
    return $out;
}
function render_ads(string $position): void {
    $ads = get_active_ads($position);
    if (empty($ads)) return;
    echo '<div class="ads-container ads-' . htmlspecialchars($position) . '">';
    echo '<span class="ad-label">विज्ञापन</span>';
    foreach ($ads as $ad) echo render_ad($ad);
    echo '</div>';
}

// ── Newsletter ─────────────────────────────────────────────
function save_newsletter_email(string $email): bool {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return false;
    try {
        db_query("INSERT OR IGNORE INTO newsletter_subscribers (email) VALUES (?)", [$email]);
        return true;
    } catch (Exception $e) { return false; }
}

// ── Dashboard stats ────────────────────────────────────────
function get_dashboard_stats(): array {
    $total      = db_count("SELECT COUNT(*) FROM articles");
    $published  = db_count("SELECT COUNT(*) FROM articles WHERE status='published'");
    $draft      = db_count("SELECT COUNT(*) FROM articles WHERE status='draft'");
    $views      = db_count("SELECT COALESCE(SUM(views),0) FROM articles");
    $cats       = db_count("SELECT COUNT(*) FROM categories");
    $auths      = db_count("SELECT COUNT(*) FROM authors");
    $ads_total  = db_count("SELECT COUNT(*) FROM advertisements");
    $ads_active = db_count("SELECT COUNT(*) FROM advertisements WHERE active=1");
    try { $subscribers = db_count("SELECT COUNT(*) FROM newsletter_subscribers"); }
    catch (Exception $e) { $subscribers = 0; }
    $bycat  = db_fetchAll(
        "SELECT c.name, c.name_np, COUNT(a.id) AS cnt
         FROM categories c LEFT JOIN articles a ON a.category_id=c.id AND a.status='published'
         GROUP BY c.id ORDER BY cnt DESC LIMIT 10");
    $recent = get_articles(['status'=>'published','limit'=>5]);
    return compact('total','published','draft','views','cats','auths','ads_total','ads_active','subscribers','bycat','recent');
}
