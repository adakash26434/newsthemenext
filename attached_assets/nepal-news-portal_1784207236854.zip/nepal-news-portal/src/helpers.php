<?php
require_once __DIR__ . '/config.php';

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string {
    return SITE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}

function current_url(): string {
    return strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
}

function slug_from_title(string $title): string {
    $title = mb_strtolower($title);
    $title = preg_replace('/[^\w\s-]/u', '', $title);
    $title = preg_replace('/[\s_-]+/', '-', $title);
    return trim($title, '-') ?: 'article-' . time();
}

function format_date(string $date, bool $nepali = false): string {
    $ts = strtotime($date);
    if (!$ts) return $date;
    if ($nepali) {
        $year  = (int)date('Y', $ts) + 57;
        $month = (int)date('n', $ts);
        $day   = (int)date('j', $ts);
        $months = NP_MONTHS;
        return sprintf('%d %s %d', $year, $months[$month] ?? '', $day);
    }
    return date('M j, Y', $ts);
}

function time_ago(string $date): string {
    $diff = time() - strtotime($date);
    if ($diff < 60)     return 'भर्खरै';
    if ($diff < 3600)   return round($diff/60)   . ' मिनेट अघि';
    if ($diff < 86400)  return round($diff/3600)  . ' घण्टा अघि';
    if ($diff < 604800) return round($diff/86400) . ' दिन अघि';
    return format_date($date, true);
}

function excerpt(string $text, int $words = 20): string {
    $stripped  = strip_tags($text);
    $words_arr = explode(' ', $stripped);
    if (count($words_arr) <= $words) return $stripped;
    return implode(' ', array_slice($words_arr, 0, $words)) . '...';
}

// ── Auth helpers ───────────────────────────────────────────

function admin_check(): void {
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['admin_logged_in'])) redirect('admin/login');
}

function admin_login(string $username, string $password): bool {
    $u = setting('admin_username', DEFAULT_ADMIN_USERNAME);
    $p = setting('admin_password', DEFAULT_ADMIN_PASSWORD);
    return $username === $u && $password === $p;
}

function is_admin(): bool {
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) session_start();
    return !empty($_SESSION['admin_logged_in']);
}

function csrf_token(): string {
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
}

function csrf_check(): void {
    if (!hash_equals(csrf_token(), $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        die('Invalid CSRF token');
    }
}

function flash_set(string $key, string $msg): void {
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'][$key] = $msg;
}

function flash_get(string $key): ?string {
    session_name(SESSION_NAME);
    if (session_status() === PHP_SESSION_NONE) session_start();
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $msg;
}

// ── Pagination ─────────────────────────────────────────────

function paginate(int $total, int $per_page, int $current_page, string $url_pattern): array {
    $total_pages  = max(1, (int)ceil($total / $per_page));
    $current_page = max(1, min($current_page, $total_pages));
    return [
        'total'       => $total,
        'per_page'    => $per_page,
        'current'     => $current_page,
        'total_pages' => $total_pages,
        'offset'      => ($current_page - 1) * $per_page,
        'url_pattern' => $url_pattern,
        'has_prev'    => $current_page > 1,
        'has_next'    => $current_page < $total_pages,
        'prev_page'   => $current_page - 1,
        'next_page'   => $current_page + 1,
    ];
}

// ── Utility ────────────────────────────────────────────────

function category_color(string $color = ''): string {
    return $color ?: setting('primary_color', DEFAULT_COLOR_ACCENT);
}

function np_number(int $n): string {
    return str_replace(
        ['0','1','2','3','4','5','6','7','8','9'],
        ['०','१','२','३','४','५','६','७','८','९'],
        (string)$n);
}

// Dynamic site identity
function site_name(): string      { return setting('site_name', DEFAULT_SITE_NAME); }
function site_name_en(): string   { return setting('site_name_en', DEFAULT_SITE_NAME_EN); }
function site_tagline(): string   { return setting('site_tagline', DEFAULT_SITE_TAGLINE); }
function site_logo_url(): string  { return setting('site_logo_url', ''); }
function site_logo_text(): string { return setting('site_logo_text', site_name()); }
function primary_color(): string  { return setting('primary_color', DEFAULT_COLOR_PRIMARY); }
function nav_color(): string      { return setting('nav_color', DEFAULT_COLOR_NAV); }
function accent_color(): string   { return setting('accent_color', DEFAULT_COLOR_ACCENT); }
