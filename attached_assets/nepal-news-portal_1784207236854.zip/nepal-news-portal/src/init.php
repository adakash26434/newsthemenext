<?php
/**
 * Database initializer — creates all tables and seeds data.
 * Auto-runs on first visit. Safe to re-run.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

$db = get_db();

// ── Schema ─────────────────────────────────────────────────
$db->exec("
CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS categories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  name_np    TEXT,
  slug       TEXT NOT NULL UNIQUE,
  color      TEXT DEFAULT '#991B1B',
  icon       TEXT DEFAULT '',
  sort_order INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS authors (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  name_np    TEXT,
  slug       TEXT NOT NULL UNIQUE,
  bio        TEXT,
  avatar_url TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tags (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  slug       TEXT NOT NULL UNIQUE,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS articles (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  title_np     TEXT,
  slug         TEXT NOT NULL UNIQUE,
  content      TEXT NOT NULL,
  content_np   TEXT,
  summary      TEXT NOT NULL,
  summary_np   TEXT,
  language     TEXT NOT NULL DEFAULT 'np',
  status       TEXT NOT NULL DEFAULT 'draft',
  featured     INTEGER NOT NULL DEFAULT 0,
  image_url    TEXT,
  views        INTEGER NOT NULL DEFAULT 0,
  category_id  INTEGER NOT NULL REFERENCES categories(id),
  author_id    INTEGER NOT NULL REFERENCES authors(id),
  published_at TEXT,
  created_at   TEXT DEFAULT (datetime('now')),
  updated_at   TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS article_tags (
  article_id INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  tag_id     INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);
CREATE TABLE IF NOT EXISTS advertisements (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT NOT NULL,
  type       TEXT NOT NULL DEFAULT 'image',
  image_url  TEXT,
  code       TEXT,
  link_url   TEXT,
  position   TEXT NOT NULL DEFAULT 'sidebar-top',
  active     INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER DEFAULT 0,
  clicks     INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT NOT NULL UNIQUE,
  confirmed  INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_articles_status   ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_featured ON articles(featured);
CREATE INDEX IF NOT EXISTS idx_articles_slug     ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_cat      ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_views    ON articles(views DESC);
CREATE INDEX IF NOT EXISTS idx_articles_language ON articles(language);
CREATE INDEX IF NOT EXISTS idx_ads_position      ON advertisements(position, active);
");

// Add icon column to categories if missing (migration)
try { $db->exec("ALTER TABLE categories ADD COLUMN icon TEXT DEFAULT ''"); }
catch (Exception $e) { /* already exists */ }

// Add epaper_url setting if missing
// (handled by default_settings below)

// ── Seed settings ──────────────────────────────────────────
$defaults = [
    'site_name'        => 'न्यूज पोर्टल नेपाल',
    'site_name_en'     => 'News Portal Nepal',
    'site_tagline'     => 'नेपालको विश्वसनीय समाचार पोर्टल',
    'site_logo_url'    => '',
    'site_logo_text'   => 'न्यूज पोर्टल',
    'primary_color'    => '#7F1D1D',
    'nav_color'        => '#7F1D1D',
    'accent_color'     => '#991B1B',
    'contact_email'    => 'info@newsportal.com.np',
    'contact_phone'    => '+977-01-4xxxxxx',
    'contact_address'  => 'काठमाडौं, नेपाल',
    'social_facebook'  => '',
    'social_twitter'   => '',
    'social_youtube'   => '',
    'social_instagram' => '',
    'footer_about'     => 'नेपालको अग्रणी समाचार पोर्टल। ताजा बजार समाचार, राजनीति, खेलकुद र विश्व समाचार।',
    'admin_username'   => 'admin',
    'admin_password'   => 'admin123',
    'ticker_label'     => 'ताजा खबर',
    'epaper_url'       => '',
    'google_analytics' => '',
    'meta_keywords'    => 'नेपाल समाचार, ताजा खबर, nepal news',
];
$stmt = $db->prepare("INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)");
foreach ($defaults as $k => $v) $stmt->execute([$k, $v]);

// ── Seed categories ────────────────────────────────────────
$cats = [
    ['अर्थतन्त्र','Economy',       'arthatantra',  '#991B1B','💰',1],
    ['बैंकिंग',   'Banking',       'banking',      '#1D4ED8','🏦',2],
    ['बिमा',      'Insurance',     'bima',         '#065F46','🛡️',3],
    ['सेयर बजार', 'Share Market',  'share-bazar',  '#7C3AED','📈',4],
    ['कर्पोरेट',  'Corporate',     'corporate',    '#B45309','🏢',5],
    ['पर्यटन',    'Tourism',       'paryatan',     '#0E7490','✈️',6],
    ['राजनीति',   'Politics',      'rajniti',      '#BE123C','🏛️',7],
    ['समाज',      'Society',       'samaj',        '#16A34A','👥',8],
    ['विकास',     'Development',   'bikas',        '#CA8A04','🔨',9],
    ['विचार',     'Opinion',       'bichar',       '#9333EA','💭',10],
    ['अन्तर्वार्ता','Interview',   'antarwarta',   '#0F766E','🎤',11],
    ['सम्पादकीय', 'Editorial',     'sampadakiya',  '#C2410C','📝',12],
    ['खेलकुद',    'Sports',        'sports',       '#15803D','⚽',13],
    ['प्रविधि',   'Technology',    'technology',   '#1E40AF','💻',14],
    ['विश्व',     'World',         'world',        '#6B21A8','🌍',15],
];
$stmt = $db->prepare("INSERT OR IGNORE INTO categories (name_np,name,slug,color,icon,sort_order) VALUES (?,?,?,?,?,?)");
foreach ($cats as $c) $stmt->execute($c);

// Update icons for existing categories
$icon_stmt = $db->prepare("UPDATE categories SET icon=? WHERE slug=? AND (icon IS NULL OR icon='')");
foreach ($cats as $c) $icon_stmt->execute([$c[4], $c[2]]);

// ── Seed authors ───────────────────────────────────────────
$authors = [
    ['Ramesh Sharma','रमेश शर्मा','ramesh-sharma','वरिष्ठ आर्थिक पत्रकार, काठमाडौं। १५ वर्षको अनुभव।'],
    ['Sita Adhikari','सीता अधिकारी','sita-adhikari','व्यापार तथा वित्त विशेषज्ञ पत्रकार।'],
    ['Samwaddatta Team','संवाददाता','team','न्यूज पोर्टल समाचार टिम।'],
    ['Bikash Thapa','विकास थापा','bikash-thapa','बैंकिंग तथा वित्त पत्रकार।'],
    ['Anita Karmacharya','अनिता कर्माचार्य','anita-karmacharya','राजनीति तथा समाज पत्रकार।'],
];
$stmt = $db->prepare("INSERT OR IGNORE INTO authors (name,name_np,slug,bio) VALUES (?,?,?,?)");
foreach ($authors as $a) $stmt->execute($a);

// ── Seed tags ──────────────────────────────────────────────
$tags = [
    ['नेपाल राष्ट्र बैंक','nrb'],['सेयर बजार','share-market'],
    ['GDP','gdp'],['कर','kar'],['लगानी','lagani'],
    ['ब्याज दर','byaj-dar'],['रेमिट्यान्स','remittance'],
    ['निर्वाचन','election'],['प्रविधि','tech'],['स्वास्थ्य','health'],
    ['बजेट','budget'],['पर्यटन','tourism'],
];
$stmt = $db->prepare("INSERT OR IGNORE INTO tags (name,slug) VALUES (?,?)");
foreach ($tags as $t) $stmt->execute($t);

// ── Seed articles ──────────────────────────────────────────
$count = (int)$db->query("SELECT COUNT(*) FROM articles")->fetchColumn();
if ($count === 0) {
    $cat_ids  = $db->query("SELECT slug,id FROM categories")->fetchAll(PDO::FETCH_KEY_PAIR);
    $auth_ids = $db->query("SELECT slug,id FROM authors")->fetchAll(PDO::FETCH_KEY_PAIR);

    $articles_seed = [
        ['स्थायी निक्षेप सुविधामा लचकता: राष्ट्र बैंकको नयाँ नीति','banking','team',1,2,'नेपाल राष्ट्र बैंकले स्थायी निक्षेप सुविधामा नयाँ नीति ल्याएको छ। बैंकहरूलाई थप लचकता दिने गरी यो व्यवस्था गरिएको हो। राष्ट्र बैंकका अनुसार यो नीति तत्काल लागु हुनेछ र सबै वाणिज्य बैंकहरूले यसलाई पालना गर्नुपर्नेछ। नयाँ व्यवस्थाले बैंकहरूको तरलता व्यवस्थापनमा सहयोग पुग्ने अपेक्षा छ।','नेपाल राष्ट्र बैंकले स्थायी निक्षेप सुविधामा लचकता दिने नीति ल्यायो।'],
        ['नेपालको जीडीपी वृद्धि दर ४.५ प्रतिशत पुग्ने अनुमान','arthatantra','ramesh-sharma',1,3,'अन्तर्राष्ट्रिय मुद्रा कोषले नेपालको आर्थिक वृद्धि दर यस आर्थिक वर्षमा ४.५ प्रतिशत पुग्ने प्रक्षेपण गरेको छ। यो गत वर्षको तुलनामा उल्लेखनीय सुधार हो।','IMF ले नेपालको GDP ४.५ प्रतिशत बढ्ने प्रक्षेपण गर्यो।'],
        ['नेप्से परिसूचक ३५ अंकले बढ्यो, बैंकिङमा उत्साह','share-bazar','sita-adhikari',1,4,'नेपाल स्टक एक्सचेन्जमा आजको कारोबारमा उत्साहजनक वातावरण रह्यो। नेप्से परिसूचक ३५ अंकले बढेर बन्द भएको छ। बैंकिंग क्षेत्रका सेयरहरूमा विशेष उत्साह देखियो।','नेप्से ३५ अंकले बढ्यो। बैंकिङ क्षेत्र तेजीमा।'],
        ['पर्यटन वर्षमा १० लाख पर्यटक भित्र्याउने लक्ष्य','paryatan','team',0,6,'नेपाल सरकारले चालू पर्यटन वर्षमा १० लाख पर्यटक भित्र्याउने लक्ष्य राखेको छ। यो लक्ष्य हासिल गर्न विभिन्न रणनीतिहरू तयार पारिएको छ।','पर्यटन वर्षमा १० लाख पर्यटक भित्र्याउने लक्ष्य तोकियो।'],
        ['मौद्रिक नीतिले ब्याज दर घटाउने संकेत','arthatantra','ramesh-sharma',0,8,'नेपाल राष्ट्र बैंकको आगामी मौद्रिक नीतिमा ब्याज दर घटाउने संकेत मिलेको छ। बजारमा तरलताको अवस्था सुधार भएकाले यो निर्णय लिन सकिने विश्लेषकहरूको भनाइ छ।','राष्ट्र बैंकले ब्याज दर घटाउने संकेत दियो।'],
        ['रेमिट्यान्स आप्रवाहमा उल्लेखनीय वृद्धि','arthatantra','bikash-thapa',0,10,'चालू आर्थिक वर्षको पहिलो ६ महिनामा रेमिट्यान्स आप्रवाहमा उल्लेखनीय वृद्धि भएको छ। राष्ट्र बैंकका अनुसार यस अवधिमा रेमिट्यान्स ८ खर्ब रुपैयाँ नाघेको छ।','रेमिट्यान्स ८ खर्ब रुपैयाँ नाघ्यो।'],
        ['काठमाडौं महानगरले नयाँ व्यापार नीति ल्याउने','corporate','sita-adhikari',0,12,'काठमाडौं महानगरपालिकाले व्यापार व्यवसायलाई सहज बनाउन नयाँ नीति ल्याउने भएको छ। यस नीतिले साना तथा मझौला उद्योगलाई विशेष प्राथमिकता दिनेछ।','काठमाडौं महानगरले व्यापार सहजीकरण नीति ल्याउँदैछ।'],
        ['नेपाल जीवन बिमाको AGM सम्पन्न','bima','bikash-thapa',0,14,'नेपाल जीवन बिमा कम्पनीको वार्षिक साधारण सभा काठमाडौंमा सम्पन्न भयो। कम्पनीले गत वर्ष उल्लेखनीय नाफा आर्जन गरेको जनाइएको छ।','नेपाल जीवन बिमाको AGM सम्पन्न; राम्रो नाफा।'],
        ['प्रविधि क्षेत्रमा नेपाली स्टार्टअपको उदय','technology','anita-karmacharya',0,16,'नेपालमा प्रविधि स्टार्टअपहरूको संख्या तीव्र गतिमा बढिरहेको छ। गत वर्ष मात्र ५०० भन्दा बढी नयाँ प्रविधि कम्पनी दर्ता भएका छन्।','नेपालमा प्रविधि स्टार्टअप बूम।'],
        ['खेलकुद: नेपाली क्रिकेट टिमको नयाँ सफलता','sports','team',0,18,'नेपाली क्रिकेट टिमले अन्तर्राष्ट्रिय टुर्नामेन्टमा उल्लेखनीय सफलता हासिल गरेको छ। यो सफलताले नेपाली खेलाडीहरूको मनोबल उच्च राखेको छ।','नेपाली क्रिकेट टिमको शानदार प्रदर्शन।'],
    ];

    $stmt = $db->prepare(
        "INSERT OR IGNORE INTO articles
         (title,category_id,author_id,featured,views,content,summary,language,status,published_at)
         VALUES (?,?,?,?,?,?,?,'np','published',datetime('now',?))");

    foreach ($articles_seed as $art) {
        [$title,$cat_slug,$auth_slug,$featured,$views,$content,$summary] = $art;
        $hours = $art[7] ?? 2;
        $stmt->execute([
            $title,
            $cat_ids[$cat_slug]   ?? 1,
            $auth_ids[$auth_slug] ?? 1,
            $featured, $views, $content, $summary,
            "-{$hours} hours"
        ]);
    }
}

// ── Seed sample ads ────────────────────────────────────────
$ad_count = (int)$db->query("SELECT COUNT(*) FROM advertisements")->fetchColumn();
if ($ad_count === 0) {
    $db->exec("INSERT INTO advertisements (title,type,image_url,link_url,position,active,sort_order) VALUES
               ('Header Banner','image','','https://example.com','header-banner',0,1),
               ('Sidebar Ad 1','image','','https://example.com','sidebar-top',0,1),
               ('Sidebar Ad 2','image','','https://example.com','sidebar-bottom',0,2),
               ('Article Middle Ad','image','','https://example.com','article-middle',0,1),
               ('Article Bottom Ad','image','','https://example.com','article-bottom',0,1)");
}

if (php_sapi_name() === 'cli') {
    echo "✅ Database initialized.\n";
    echo "   Admin: admin / admin123\n";
    echo "   Change at: /admin/settings\n";
}
